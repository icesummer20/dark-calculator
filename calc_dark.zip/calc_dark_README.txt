-calc dark
Dark theme calculator for Windows x64

This is not official.
I changed the color using the Windows 7 x64 calculator.(icon too)
and hiding menu bar.(shortcut key and context menu still works)

-Tested Windows 10 1909 x64